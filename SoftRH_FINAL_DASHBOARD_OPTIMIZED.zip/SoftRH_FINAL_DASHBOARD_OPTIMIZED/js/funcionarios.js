class FuncionariosManager {
  constructor() {
    this.currentEditId = null;
    this.init();
  }
  init() {
    this.setupEventListeners();
    this.loadFuncionarios();
  }
  setupEventListeners() {
    const addBtn = document.getElementById('addFuncionario');
    if (addBtn) {
      addBtn.addEventListener('click', () => this.openFuncionarioModal());
    }
    const form = document.getElementById('funcionarioForm');
    if (form) {
      form.addEventListener('submit', e => this.handleFuncionarioSubmit(e));
    }
    const cancelBtn = document.getElementById('cancelFuncionario');
    const closeBtn = document.getElementById('closeFuncionarioModal');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => this.closeFuncionarioModal());
    }
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.closeFuncionarioModal());
    }
    const departamentoFilter = document.getElementById('departamentoFilter');
    const statusFilter = document.getElementById('statusFilter');
    if (departamentoFilter) {
      departamentoFilter.addEventListener('change', () => this.applyFilters());
    }
    if (statusFilter) {
      statusFilter.addEventListener('change', () => this.applyFilters());
    }
  }
  loadFuncionarios() {
    const funcionarios = storageManager.getFuncionarios();
    this.displayFuncionarios(funcionarios);
  }
  displayFuncionarios(funcionarios) {
    const tbody = document.getElementById('funcionariosTableBody');
    if (!tbody) return;
    if (funcionarios.length === 0) {
      tbody.innerHTML = `
                <tr>
                    <td colspan="8" style="text-align: center; padding: 2rem; color: var(--gray-500);">
                        <i class="fas fa-users" style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                        <p>Nenhum funcionário cadastrado</p>
                        <button class="btn btn-primary" onclick="window.funcionariosManager.openFuncionarioModal()">
                            <i class="fas fa-plus"></i> Adicionar Primeiro Funcionário
                        </button>
                    </td>
                </tr>
            `;
      return;
    }
    tbody.innerHTML = funcionarios.map(funcionario => `
            <tr>
                <td>#${funcionario.id.substring(0, 8)}</td>
                <td>
                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                        <div class="user-avatar" style="width: 32px; height: 32px; font-size: 0.875rem;">
                            ${funcionario.nome.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </div>
                        <div>
                            <div style="font-weight: 600; color: var(--gray-800);">${funcionario.nome}</div>
                            <div style="font-size: 0.75rem; color: var(--gray-500);">${funcionario.email}</div>
                        </div>
                    </div>
                </td>
                <td>${funcionario.cargo}</td>
                <td>
                    <span class="status-badge" style="background-color: ${this.getDepartamentoColor(funcionario.departamento)}20; color: ${this.getDepartamentoColor(funcionario.departamento)};">
                        ${funcionario.departamento}
                    </span>
                </td>
                <td>${funcionario.email}</td>
                <td>${new Date(funcionario.dataAdmissao).toLocaleDateString('pt-BR')}</td>
                <td>
                    <span class="status-badge status-${funcionario.status}">
                        ${funcionario.status === 'ativo' ? 'Ativo' : funcionario.status === 'ferias' ? 'De Férias' : 'Afastado'}
                    </span>
                </td>
                <td>
                    <div class="actions">
                        <button class="btn btn-small btn-secondary" onclick="window.funcionariosManager.editFuncionario('${funcionario.id}')" title="Editar">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-small btn-danger" onclick="window.funcionariosManager.deleteFuncionario('${funcionario.id}')" title="Excluir">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
  }
  getDepartamentoColor(departamento) {
    const colors = {
      'TI': '#2563eb',
      'RH': '#10b981',
      'Vendas': '#f59e0b',
      'Marketing': '#8b5cf6',
      'Financeiro': '#ef4444'
    };
    return colors[departamento] || '#6b7280';
  }
  openFuncionarioModal(funcionarioId = null) {
    const modal = document.getElementById('funcionarioModal');
    const form = document.getElementById('funcionarioForm');
    const title = document.getElementById('funcionarioModalTitle');
    if (!modal || !form) return;
    this.currentEditId = funcionarioId;
    if (funcionarioId) {
      title.textContent = 'Editar Funcionário';
      const funcionario = storageManager.getFuncionarioById(funcionarioId);
      if (funcionario) {
        this.populateFuncionarioForm(funcionario);
      }
    } else {
      title.textContent = 'Adicionar Funcionário';
      form.reset();
      document.getElementById('status').value = 'ativo';
      document.getElementById('dataAdmissao').value = new Date().toISOString().split('T')[0];
    }
    modal.classList.add('active');
  }
  closeFuncionarioModal() {
    const modal = document.getElementById('funcionarioModal');
    if (modal) {
      modal.classList.remove('active');
    }
    this.currentEditId = null;
  }
  populateFuncionarioForm(funcionario) {
    const fields = ['nome', 'email', 'cargo', 'departamento', 'dataAdmissao', 'salario', 'telefone', 'status'];
    fields.forEach(field => {
      const element = document.getElementById(field);
      if (element && funcionario[field] !== undefined) {
        element.value = funcionario[field];
      }
    });
  }
  handleFuncionarioSubmit(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const funcionario = {
      nome: document.getElementById('nome').value,
      email: document.getElementById('email').value,
      cargo: document.getElementById('cargo').value,
      departamento: document.getElementById('departamento').value,
      dataAdmissao: document.getElementById('dataAdmissao').value,
      salario: parseFloat(document.getElementById('salario').value) || 0,
      telefone: document.getElementById('telefone').value,
      status: document.getElementById('status').value
    };
    if (!this.validateFuncionario(funcionario)) {
      return;
    }
    let sucesso = false;
    if (this.currentEditId) {
      sucesso = storageManager.updateFuncionario(this.currentEditId, funcionario);
      if (sucesso) {
        window.app.showToast('Funcionário atualizado com sucesso!', 'success');
      }
    } else {
      const novoFuncionario = storageManager.addFuncionario(funcionario);
      if (novoFuncionario) {
        sucesso = true;
        window.app.showToast('Funcionário adicionado com sucesso!', 'success');
      }
    }
    if (sucesso) {
      this.closeFuncionarioModal();
      this.loadFuncionarios();
      if (window.app && window.app.currentSection === 'dashboard') {
        window.app.updateDashboard();
      }
    } else {
      window.app.showToast('Erro ao salvar funcionário', 'error');
    }
  }
  validateFuncionario(funcionario) {
    const errors = [];
    if (!funcionario.nome || funcionario.nome.trim().length < 3) {
      errors.push('Nome deve ter pelo menos 3 caracteres');
    }
    if (!funcionario.email || !this.isValidEmail(funcionario.email)) {
      errors.push('Email inválido');
    }
    if (!funcionario.cargo || funcionario.cargo.trim().length < 2) {
      errors.push('Cargo deve ter pelo menos 2 caracteres');
    }
    if (!funcionario.departamento) {
      errors.push('Departamento é obrigatório');
    }
    if (!funcionario.dataAdmissao) {
      errors.push('Data de admissão é obrigatória');
    }
    if (funcionario.salario < 0) {
      errors.push('Salário não pode ser negativo');
    }
    if (errors.length > 0) {
      window.app.showToast(errors[0], 'error');
      return false;
    }
    return true;
  }
  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
  editFuncionario(id) {
    this.openFuncionarioModal(id);
  }
  deleteFuncionario(id) {
    if (confirm('Tem certeza que deseja excluir este funcionário?')) {
      const sucesso = storageManager.deleteFuncionario(id);
      if (sucesso) {
        window.app.showToast('Funcionário excluído com sucesso!', 'success');
        this.loadFuncionarios();
        if (window.app && window.app.currentSection === 'dashboard') {
          window.app.updateDashboard();
        }
      } else {
        window.app.showToast('Erro ao excluir funcionário', 'error');
      }
    }
  }
  applyFilters() {
    const departamento = document.getElementById('departamentoFilter').value;
    const status = document.getElementById('statusFilter').value;
    const filtros = {};
    if (departamento) filtros.departamento = departamento;
    if (status) filtros.status = status;
    const funcionariosFiltrados = storageManager.filterFuncionarios(filtros);
    this.displayFuncionarios(funcionariosFiltrados);
  }
  getEstatisticasPorDepartamento() {
    const funcionarios = storageManager.getFuncionarios();
    const estatisticas = {};
    funcionarios.forEach(f => {
      if (!estatisticas[f.departamento]) {
        estatisticas[f.departamento] = 0;
      }
      estatisticas[f.departamento]++;
    });
    return estatisticas;
  }
  getEstatisticasPorStatus() {
    const funcionarios = storageManager.getFuncionarios();
    const estatisticas = {
      ativo: 0,
      ferias: 0,
      afastado: 0
    };
    funcionarios.forEach(f => {
      if (estatisticas[f.status] !== undefined) {
        estatisticas[f.status]++;
      }
    });
    return estatisticas;
  }
  getAniversariantesDoMes() {
    const funcionarios = storageManager.getFuncionarios();
    const mesAtual = new Date().getMonth();
    return funcionarios.filter(f => {
      const dataNascimento = new Date(f.dataNascimento);
      return dataNascimento.getMonth() === mesAtual;
    });
  }
  getFuncionariosRecentes(dias = 30) {
    const funcionarios = storageManager.getFuncionarios();
    const dataLimite = new Date();
    dataLimite.setDate(dataLimite.getDate() - dias);
    return funcionarios.filter(f => {
      const dataAdmissao = new Date(f.dataAdmissao);
      return dataAdmissao >= dataLimite;
    });
  }
  exportarFuncionarios() {
    const funcionarios = storageManager.getFuncionarios();
    const csv = this.convertToCSV(funcionarios);
    const blob = new Blob([csv], {
      type: 'text/csv'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `funcionarios-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    window.app.showToast('Funcionários exportados com sucesso!', 'success');
  }
  convertToCSV(data) {
    const headers = ['Nome', 'Email', 'Cargo', 'Departamento', 'Data Admissão', 'Salário', 'Status'];
    const csvContent = [headers.join(','), ...data.map(row => [row.nome, row.email, row.cargo, row.departamento, new Date(row.dataAdmissao).toLocaleDateString('pt-BR'), row.salario || 0, row.status].map(field => `"${field}"`).join(','))].join('\n');
    return csvContent;
  }
}
window.funcionariosManager = new FuncionariosManager();
(function () {
  function getDB() {
    try {
      return window._softRH_storage_manager ? window._softRH_storage_manager.getAllData() : JSON.parse(localStorage.getItem('soft_rh_db') || '{}');
    } catch (e) {
      console.error(e);
      return null;
    }
  }
  function saveDB(db) {
    try {
      if (window._softRH_storage_manager) window._softRH_storage_manager.saveAllData(db);else localStorage.setItem('soft_rh_db', JSON.stringify(db));
    } catch (e) {
      console.error(e);
    }
  }
  function refreshFuncionariosTable() {
    const db = getDB();
    if (!db || !db.funcionarios) return;
    const tbody = document.querySelector('#funcionariosTable tbody') || document.querySelector('#table-funcionarios tbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    db.funcionarios.forEach(f => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${f.id || ''}</td><td class="fnome">${f.nome || ''}</td><td>${f.cargo || ''}</td><td>${f.departamento || ''}</td><td>${f.email || ''}</td><td><span class="status">${f.status || 'Ativo'}</span></td><td><button class="btn-edit" data-id="${f.id}">Editar</button><button class="btn-del" data-id="${f.id}">Excluir</button></td>`;
      tbody.appendChild(tr);
    });
    tbody.querySelectorAll('.btn-edit').forEach(b => b.addEventListener('click', () => openEditFuncionario(b.dataset.id)));
    tbody.querySelectorAll('.btn-del').forEach(b => b.addEventListener('click', () => {
      if (confirm('Excluir?')) deleteFuncionario(b.dataset.id);
    }));
  }
  function openEditFuncionario(id) {
    const db = getDB();
    const f = (db.funcionarios || []).find(x => String(x.id) === String(id));
    if (!f) return alert('Funcionário não encontrado');
    const modal = document.getElementById('funcionarioModal');
    if (modal) {
      modal.querySelector('#funcNome').value = f.nome || '';
      modal.querySelector('#funcEmail').value = f.email || '';
      modal.querySelector('#funcCargo').value = f.cargo || '';
      modal.querySelector('#funcDept').value = f.departamento || '';
      modal.querySelector('#funcDataAdm').value = f.contratadoEm || '';
      modal.querySelector('#funcSalario').value = f.salario || '';
      modal.querySelector('#funcTelefone').value = f.telefone || '';
      modal.querySelector('#funcStatus').value = f.status || 'Ativo';
      modal.setAttribute('data-edit-id', f.id);
      modal.style.display = 'block';
    } else {
      const nome = prompt('Nome:', f.nome || '');
      if (!nome) return;
      f.nome = nome;
      saveDB(db);
      refreshFuncionariosTable();
    }
  }
  function deleteFuncionario(id) {
    const db = getDB();
    db.funcionarios = (db.funcionarios || []).filter(x => String(x.id) !== String(id));
    saveDB(db);
    refreshFuncionariosTable();
  }
  function newFuncionario() {
    const db = getDB();
    const nextId = db.metadata && db.metadata.nextFuncionarioId ? db.metadata.nextFuncionarioId++ : db.funcionarios.length ? Math.max(...db.funcionarios.map(x => x.id)) + 1 : 1;
    const f = {
      id: nextId,
      nome: 'Novo Funcionário',
      email: '',
      cargo: '',
      departamento: '',
      contratadoEm: new Date().toISOString().slice(0, 10),
      salario: '',
      telefone: '',
      status: 'Ativo'
    };
    db.funcionarios.push(f);
    if (!db.metadata) db.metadata = {};
    db.metadata.nextFuncionarioId = nextId + 1;
    saveDB(db);
    refreshFuncionariosTable();
    openEditFuncionario(nextId);
  }
  window.FuncionariosModule = {
    refreshFuncionariosTable,
    newFuncionario,
    openEditFuncionario
  };
  document.addEventListener('DOMContentLoaded', () => {
    try {
      document.querySelectorAll('.btn-add-funcionario, .btn-addemployee, #btnNovoFuncionario').forEach(b => b.addEventListener('click', newFuncionario));
    } catch (e) {}
    ;
    setTimeout(refreshFuncionariosTable, 200);
  });
})();